package com.eva.enums;

public enum LoggingLevel {

	ALL, DEBUG, ERROR, FATAL, INFO, OFF, TRACE, WARN;
	
}
