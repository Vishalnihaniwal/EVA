package com.eva.Business;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.eva.SomePojos.RuntimeVals;
import com.eva.Utils.FuncBank;
import com.relevantcodes.extentreports.LogStatus;

import problems.evaException;

import com.eva.Reports.Reporting;

public class GMAIL {
	FuncBank fb ;
	WebDriver driver; 
	Reporting repo;
	
	public GMAIL(WebDriver driver, Reporting repo)
	{
		System.out.println("In cosntructor");
		this.driver = driver;
		this.repo = repo;
		fb = new FuncBank(driver, repo);
	}
	public void LoginGmail() throws evaException, InterruptedException
	{
		System.out.println("Login Method to open Google site");
		driver.get("https://www.google.com/");
		Thread.sleep(5000);
//		fb.performAction("verifyPageTitle", "", "", "", "", false);
////		fb.performAction("Click", "Xpath", "//a[text()='Login']", "", "Click on login button", false);
//		System.out.println("Sample method of gmail on browser" + RuntimeVals.configXML.get("BROWSER"+Thread.currentThread().getName()) );
////		System.out.println(Thread.currentThread().getName());
//		System.out.println("Click on Login");
////		 driver.findElement(By.linkText("Login")).click();
//		
//		driver.findElement(By.xpath("//input[@name='q']")).click();
//		
//		 System.out.println("Clear field");
//	    driver.findElement(By.id("jfHeader_username")).clear();
//	    System.out.println("Enter user name");
//	    driver.findElement(By.id("jfHeader_username")).sendKeys("test909142");
//	    System.out.println("Clear passwoerd field");
//	    driver.findElement(By.id("jfHeader_password")).clear();
//	    System.out.println("Enter password");
//	    driver.findElement(By.id("jfHeader_password")).sendKeys("test@2018");
//	    driver.findElement(By.id("signinButton")).click();
//	    driver.findElement(By.xpath("//ul[@id='jfHeader-userProfile']/li/a")).click();
//	    System.out.println("Click logout link");
//	    driver.findElement(By.linkText("Logout")).click();
	}
	
	public  void dellCase() throws InterruptedException, evaException
	{
        WebElement designedExclusivelyForYou = driver.findElement(By.xpath("//h4"));
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("arguments[0].scrollIntoView();", designedExclusivelyForYou);
        repo.logStepToReport(LogStatus.PASS, "Scroll a bit down", "Scrolled down");
        
        fb.performAction("verifyPageTitle", "", "", "", "", false);
        
        Thread.sleep(1000);
        js.executeScript("arguments[0].click();",  driver.findElement(By.xpath("//a[@href='/en-in/shop/laptops-2-in-1-pcs/sc/laptops']")));
//        driver.findElement(By.xpath("//a[@href='/en-in/shop/laptops-2-in-1-pcs/sc/laptops']")).click();
        System.out.println("Scroll done");
        Thread.sleep(1000);
        
        driver.findElement(By.xpath("(//a[@href='/en-in/shop/laptops-2-in-1-pcs/sc/laptops'])[2]")).click();
        System.out.println("Click on For Home image");
        WebElement series3000 = driver.findElement(By.xpath("//span[text()='3000 Series']")); 
        js.executeScript("arguments[0].scrollIntoView();", series3000);
        series3000.click();
        js.executeScript("arguments[0].click();",  driver.findElement(By.xpath("//a[@href='/en-in/shop/laptops-2-in-1-pcs/inspiron-15-3000/spd/inspiron-15-3000-series-laptops']")));
//        driver.findElement(By.xpath("//a[@href='/en-in/shop/laptops-2-in-1-pcs/inspiron-15-3000/spd/inspiron-15-3000-series-laptops']")).click();
        System.out.println("Last click");
	}

	public void practo()
	{
		try {
//		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//        driver.manage().window().maximize();
        driver.get("https://www.practo.com");
        driver.findElement(By.xpath("//div[contains(text(),'Pharmacy')]")).click();
        driver.findElement(By.xpath("//input[@placeholder='Search for medicines, health products and more']")).sendKeys("calpol tablet");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[contains(text(),'Calpol Tablet')]")).click();
        driver.findElement(By.xpath("//span[@class='text-white heading-epsilon-bold']")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[contains(text(),'View Cart')]")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//span[contains(text(),'Checkout')]")).click();
		}
		catch(Exception e)
		{ 
			e.printStackTrace();
		}
	}
	
	
	public void globalsqa() {
		try 
		{
			
//			fb.performAction("CLEARTEXT", "name", "dest-input", "", "clear on dest text box", false);
//			fb.performAction("SETTEXT", "name", "dest-input", "Berlin", "enter in dest text box", true);
			
			
			System.out.println("GlobalSQA starts here...");
			driver.get("http://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");	
			WebDriverWait wait=new WebDriverWait(driver, 300);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-primary btn-lg' and text()='Customer Login' ]")));
			fb.performAction("Click", "xpath", "//button[@class='btn btn-primary btn-lg' and text()='Customer Login' ]", "", "Click on login button", true);
//			driver.findElement(By.xpath("//button[@class='btn btn-primary btn-lg' and text()='Customer Login' ]")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.id("userSelect")));
			Select customer=new Select(driver.findElement(By.id("userSelect")));
			customer.selectByVisibleText("Harry Potter");
			fb.performAction("SELECTBYVALUEDD", "id", "userSelect", "Harry Potter", "Set Customer value", true);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@type='submit' and text()='Login']")));
			//driver.findElement(By.xpath("//button[@type='submit' and text()='Login']")).click();
			fb.performAction("Click", "xpath", "//button[@type='submit' and text()='Login']", "", "Click on Login button", true);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='btn btn-lg tab'and @ng-class='btnClass2']")));
			//driver.findElement(By.xpath("//button[@class='btn btn-lg tab'and @ng-class='btnClass2']")).click();
			fb.performAction("Click", "xpath", "//button[@class='btn btn-lg tab'and @ng-class='btnClass2']", "", "Click on Deposit button", true);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='number' and @placeholder='amount']")));
			//driver.findElement(By.xpath("//input[@type='number' and @placeholder='amount']")).sendKeys("50000");
			fb.performAction("SetText", "xpath", "//input[@type='number' and @placeholder='amount']", "5000", "Set Deposit amount value", true);
			
			//driver.findElement(By.xpath("//button[@type='submit' and text()='Deposit']")).click();
			fb.performAction("Click", "xpath", "//button[@type='submit' and text()='Deposit']", "", "Click on Deposit button", true);
			
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='error ng-binding' and @ng-show='message']")));
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn btn-lg tab'and @ng-class='btnClass1']")));
			//driver.findElement(By.xpath("//button[@class='btn btn-lg tab'and @ng-class='btnClass1']")).click();
			fb.performAction("Click", "xpath", "//button[@class='btn btn-lg tab'and @ng-class='btnClass1']", "", "Click on Transactions button", true);
			
			driver.navigate().refresh();
			
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("ng-binding")));
			//driver.findElement(By.xpath("//button[@ng-show='logout']")).click();
			fb.performAction("Click", "xpath", "//button[@ng-show='logout']", "", "Click on Logout button", true);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.id("userSelect")));
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//			driver.close();
			System.out.println("GlobalSQA starts ENDS here...");
		} 
		catch (Exception e) 
		{
			driver.navigate().refresh();
			e.printStackTrace();
		}
		
	}

	
	public void booking() 
	{
		try 
		{
			System.out.println("In booking method");
			driver.get("http://a.testaddressbook.com/");
			WebDriverWait wait=new WebDriverWait(driver, 300);
			
			wait.until(ExpectedConditions.elementToBeClickable(By.id("sign-in")));
			driver.findElement(By.id("sign-in")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-test='sign-up']")));
			driver.findElement(By.xpath("//a[@data-test='sign-up']")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='email' and @id='user_email']")));
			System.out.println("FOUND");
			driver.findElement(By.xpath("//input[@type='email' and @id='user_email']")).sendKeys(emailGenereation());
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys("iamironman123");
			driver.findElement(By.name("commit")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-test='addresses']")));
			driver.findElement(By.xpath("//a[@data-test='addresses']")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-test='create']")));
			driver.findElement(By.xpath("//a[@data-test='create']")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.id("address_first_name")));
			driver.findElement(By.id("address_first_name")).sendKeys("Steve");
			driver.findElement(By.id("address_last_name")).sendKeys("Rogers");
			driver.findElement(By.id("address_street_address")).sendKeys("Manhattan");
			driver.findElement(By.id("address_secondary_address")).sendKeys("New York");
			driver.findElement(By.id("address_city")).sendKeys("New York");
			Select country=new Select(driver.findElement(By.id("address_state")));
			country.selectByVisibleText("New York");
			driver.findElement(By.id("address_zip_code")).sendKeys("0771");
			driver.findElement(By.id("address_country_us")).click();
			driver.findElement(By.id("address_birthday")).sendKeys("22-01-1987");
			driver.findElement(By.id("address_age")).sendKeys("112");
			driver.findElement(By.id("address_website")).sendKeys("https://www.google.com");
			driver.findElement(By.id("address_phone")).sendKeys("9878098765");
			driver.findElement(By.name("commit")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@data-test='list']")));
			driver.findElement(By.xpath("//a[@data-test='list']")).click();
			
			driver.findElement(By.xpath("//a[@data-test='sign-out']")).click();
			System.out.println("In booking method ENDS");
//			driver.close();
		
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	private String emailGenereation() 
	{
		String firstHalf="iamironman",secondHalf="@gmail.com";
		int i=4;
		double random=1;
		
		while(i!=0)
		{
			random=random*10+Math.random();
			i--;
		}
		String email=firstHalf+(int)random+secondHalf;
		return email;
	}
}
