package problems;

public class errorsType {
	
	public problems ErrorSelection()
	{
		return (problems) new ErrorType();
	}

}
