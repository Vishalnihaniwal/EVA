package problems;

public interface problems {

	public void evaException(String ExceptionName);
	
	
}
